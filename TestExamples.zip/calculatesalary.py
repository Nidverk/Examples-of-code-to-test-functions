# a)  med TDD utvecklar du  calculateSalary(...)
# Denna funktion tar den anställdes ålder, namn,
 #timlön och antal timmar som den jobbat
# Regler för att räkna lön
# - lönen blir antal timmar *  timlönen
# - om man är mellan 25 och 45 år får man 5% bonus
# - om man är över 45 får man 6% bonus
# -om man heter Stefan får man 220 kr bonus

# Se till att enhetstester är så täckande som möjligt


def Salary():
    while True:
        age = int(input("Ange ålder:"))
        namn = input("Ange namn:")
        hourlySalary = int(input("Ange timlön:"))
        hoursWorked = int(input("Ange hur många timmar du arbetat:"))
        result = calculateSalary(namn, age, hourlySalary, hoursWorked)
        print("Salary", result)
        break
        

def calculateSalary(name, age, hourlyWage, hoursWorked):
    baseSalary = hourlyWage * hoursWorked
    bonus = 0
    if age >= 25 and age <= 45:
        bonus = baseSalary * 0.05
    elif age > 45:
        bonus = baseSalary * 0.06
    if name == 'Stefan':
        bonus += 220
    return baseSalary + bonus 

def menu():
    while True:
        # print("1. Shapes")
        print("1. Salary")    
        print("0. Exit")    
        action = input("Val:")
        # if action == "1":
        #     shapes()
        if action == "1":
            Salary()
        if action == "0":
            return
        break

if __name__ == "__main__":
    menu()



