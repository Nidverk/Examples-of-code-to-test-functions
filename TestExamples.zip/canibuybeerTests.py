# import unittest
# from canibuybeer import canIBuyBeer

# class canibuybeerTests(unittest.TestCase):
#     def test_when_age_over_18_and_at_krogen_and_promille_is_below_onepointzero_should_return_yes(self):
#         #arrange
#         age = 19
        

#         result = canIBuyBeer(age, location)
#         #act

#         #assert
#         self.assertTrue(result, True)

#     # def test_when_age_over_18_and_at_krogen_and_promille_is_above_onepointzero_should_return_yes

# unittest.main()

# import unittest
# from canibuybeer import canIBuyBeer

# class canibuybeerTests(unittest.TestCase):


#     def test_when_age_over_18_and_at_krogen_and_promille_is_above_onepointzero_should_return_no(self):
#         #arrange
#         age = 19
#         location = "K"
#         promilleHalt = 1.5

#         #act
#         result = canIBuyBeer(age, location, promilleHalt)

#         #assert
#         self.assertFalse(result)

#     def test_when_age_over_18_and_at_krogen_and_promille_is_below_onepointzero_should_return_yes(self):
#         age = 22
#         location = "K"
#         promilleHalt = 1.5

#         result = canIBuyBeer(age, location, promilleHalt)

#         self.assertTrue(result)

    
    
# unittest.main()

import unittest
from canibuybeer import canIBuyBeer

class canibuybeerTests(unittest.TestCase):

    def test_myndig_påsystemet_should_return_true(self):
        result = canIBuyBeer(25, "S", 0.5)
        self.assertTrue(result)

    def test_omyndig_påkrogen_should_return_false(self):
        result = canIBuyBeer(17, "K", 0.2)
        self.assertFalse(result)

    def test_myndig_påsystemet_promilleöver1_should_return_false(self):
        result = canIBuyBeer(20, "S", 1.5)
        self.assertFalse(result)

    def test_myndig_påkrogen_promilleöver1_should_return_false(self):
        result = canIBuyBeer(38, "K", 1.6)
        self.assertFalse(result)

    

# if __name__ == '__main__':
    
unittest.main()