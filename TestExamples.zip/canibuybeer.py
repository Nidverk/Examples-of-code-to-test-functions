# ålder      18      20
# location Krogen Systemet
# promilleHalt < 1.0
def canIBuyBeer(age,location,promilleHalt):
    if promilleHalt > 1.0:
        return False
    if location == "S" and age < 19:
        return False
    if location == "K" and age < 18:
        return False
    return True

# while True:
#     age = int(input("Enter age:"))
#     location = input("Where are you S/K")
#     promilleHalt = float(input("Ange din promille"))
#     ok = canIBuyBeer(age,location,promilleHalt)
#     if ok == True:
#         print("yes")
#     else:
#         print("no")