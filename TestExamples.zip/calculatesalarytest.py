import unittest
from calculatesalary import calculateSalary


class TestCalculateSalary(unittest.TestCase):

    def test_calculate_base_salary_no_bonus_below_age_25(self):
        self.assertEqual(calculateSalary("Robert", 22, 100, 40), 4000) # 

    def test_calculate_bonus_age_25_45(self):
        self.assertEqual(calculateSalary("Håkan", 30, 100, 40), 4200)  # Expected: 5% bonus(baseSalary * 0.05)

    def test_calculate_bonus_age_above_45(self):
        self.assertEqual(calculateSalary("Hans", 50, 100, 40), 4240)  # 6% bonus expected (baseSalary * 0.06)

    def test_calculate_bonus_specific_name_is_Stefan(self):
        self.assertEqual(calculateSalary("Stefan", 30, 100, 40), 4420)  # Bonus expected due to name "Stefan": 220

    def test_calculate_bonus_specific_name_not_Stefan(self):
        self.assertEqual(calculateSalary("Konstantin", 30, 120, 40), 5040)  # No 220 bonus expected due to name not being "Stefan"

    def test_calculate_base_salary_no_hours_worked(self):
        self.assertEqual(calculateSalary("Slacker", 26, 115, 0), 0) # No hours worked, base salary expected to be zero

    def test_calculate_bonus_special_characters_name(self):
        self.assertEqual(calculateSalary("@Lena", 50, 80, 35), 2968)  # Name with special characters, no bonus expected except for possibly age based bonus

    def test_calculate_salary_works_when_name_has_lower_case_letter(self):
        self.assertEqual(calculateSalary("findus", 21, 95, 20), 1900) # Name with lower case, should still calculate salary

    def test_calculate_salary_works_when_name_has_only_upper_case_letters(self):
        self.assertEqual(calculateSalary("JOHANNA", 48, 95, 20), 2014) # Name with only upper case letters, should still calculate salary

    
unittest.main()

